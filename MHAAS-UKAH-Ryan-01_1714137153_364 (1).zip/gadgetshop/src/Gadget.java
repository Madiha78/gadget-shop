// Class Gadget
class Gadget {

    //Private attributes
    private String model;
    private double price;
    private int weight;
    private String size;

    // Constructor to initialize the gadget
    public Gadget(String model, double price, int weight, String size) {
        this.model = model;
        this.price = price;
        this.weight = weight;
        this.size = size;
    }

    // Getter methods to retrieve the model of the gadget
    public String getModel() {

        return model;
    }

    public double getPrice() {
        return price;
    }

    public int getWeight() {
        return weight;
    }

    public String getSize() {
        return size;
    }
    // Override toString method for string representation of the gadget
    @Override
    public String toString() {
        return "Model: " + model + "\n" +
                "Price: £" + price + "\n" +
                "Weight: " + weight + " grams\n" +
                "Size: " + size + " inches\n";
    }
}

