import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

// Define the GadgetShop class which extends JFrame and implements ActionListener
public class GadgetShop extends JFrame implements ActionListener {

    // ArrayList to store gadgets
    public ArrayList<Gadget> gadgets = new ArrayList<>();

    // Text fields for input
    private JTextField textModel, textPrice, textWeight, textSize, textCredit, textMemory,
            textPhoneNo, textDuration, textDownload, textDisplayNumber;

    // Labels for text fields
    private JLabel labelModel, labelPrice, labelWeight, labelSize, labelCredit, labelMemory, labelPhoneNo,
            labelDuration, labelDownload, labelDisplayNumber;

    // Buttons for actions
    private JButton btnAddMobile;
    private JButton btnAddMP3;
    private JButton btnClear;
    private JButton btnDisplayAll;
    private JButton btnMakeCall;
    private JButton btnDownloadMusic;

    // Constructor
    public GadgetShop() {

        super("Gadget Shop");
        // defining a frame
        JFrame frame = new JFrame();

        // Initialization of GUI components
        textModel = new JTextField();
        textPrice = new JTextField();
        textWeight = new JTextField();
        textSize = new JTextField();
        textCredit = new JTextField();
        textMemory = new JTextField();
        textPhoneNo = new JTextField();
        textDuration = new JTextField();
        textDownload = new JTextField();
        textDisplayNumber = new JTextField();


        //Labels for text field
        labelModel = new JLabel("Model:");
        labelPrice = new JLabel("Price:");
        labelWeight = new JLabel("Weight:");
        labelSize = new JLabel("Size:");
        labelCredit = new JLabel("Credit:");
        labelMemory = new JLabel("Memory:");
        labelPhoneNo = new JLabel("Phone No:");
        labelDuration = new JLabel("Duration:");
        labelDownload = new JLabel("Download:");
        labelDisplayNumber = new JLabel("Display Number:");

        // action listeners for buttons
        btnAddMobile.addActionListener(this);
        btnAddMP3.addActionListener(this);
        btnClear.addActionListener(this);
        btnDisplayAll.addActionListener(this);
        btnMakeCall.addActionListener(this);
        btnDownloadMusic.addActionListener(this);

        //Panel to add text field
        JPanel panel = new JPanel();
        panel.add(textModel);
        panel.add(textPrice);
        panel.add(textWeight);
        panel.add(textSize);
        panel.add(textCredit);
        panel.add(textMemory);
        panel.add(textPhoneNo);
        panel.add(textDuration);
        panel.add(textDownload);
        panel.add(textDisplayNumber);
        panel.add(labelModel);
        panel.add(labelPrice);
        panel.add(labelWeight);
        panel.add(labelSize);
        panel.add(labelCredit);
        panel.add(labelMemory);
        panel.add(labelPhoneNo);
        panel.add(labelDuration);
        panel.add(labelDownload);
        panel.add(labelDisplayNumber);
        frame.add(panel);


        // Add buttons to panel
        panel.add(btnAddMobile);
        panel.add(btnAddMP3);
        panel.add(btnClear);
        panel.add(btnDisplayAll);
        panel.add(btnMakeCall);
        panel.add(btnDownloadMusic);


        labelModel.setBounds(5, 10, 150, 25);
        textModel.setBounds(5, 35, 150, 30);

        labelPrice.setBounds(154, 10, 150, 25);
        textPrice.setBounds(154, 35, 150, 30);

        labelWeight.setBounds(303, 10, 150, 25);
        textWeight.setBounds(303, 35, 150, 30);

        labelSize.setBounds(452, 10, 150, 25);
        textSize.setBounds(452, 35, 150, 30);

        labelCredit.setBounds(5, 70, 150, 25);
        textCredit.setBounds(5, 95, 150, 30);

        labelMemory.setBounds(154, 70, 150, 25);
        textMemory.setBounds(154, 95, 150, 30);

        labelPhoneNo.setBounds(5, 130, 150, 25);
        textPhoneNo.setBounds(5, 155, 150, 30);

        labelDuration.setBounds(154, 130, 150, 25);
        textDuration.setBounds(154, 155, 150, 30);

        labelDownload.setBounds(303, 130, 150, 25);
        textDownload.setBounds(303, 155, 150, 30);

        labelDisplayNumber.setBounds(452, 130, 150, 25);
        textDisplayNumber.setBounds(452, 155, 150, 30);

        btnAddMobile.setBounds(303, 64, 150, 30);
        btnAddMP3.setBounds(452, 64, 150, 30);
        btnClear.setBounds(303, 94, 150, 30);
        btnDisplayAll.setBounds(452, 94, 150, 30);
        btnMakeCall.setBounds(5, 184, 150, 30);
        btnDownloadMusic.setBounds(154, 184, 150, 30);

        // Set the panel as content pane
        setContentPane(panel);

        //  properties to set size, layout etc
        setSize(650, 260);
        setLayout(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }
    // Action Listener for buttons actions
    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == btnAddMobile) {
            addMobile();
        } else if (e.getSource() == btnAddMP3) {
            addMP3();
        } else if (e.getSource() == btnClear) {
            clearTextFields();
        } else if (e.getSource() == btnDisplayAll) {
            displayAllGadgets();
        } else if (e.getSource() == btnMakeCall) {
            makeCall();
        } else if (e.getSource() == btnDownloadMusic) {
            downloadMusic();
        }
    }
    // Method to add a mobile gadget
    private void addMobile() {
        try {
            String model = textModel.getText();
            double price = getDoubleValue(textPrice);
            int weight = getIntegerValue(textWeight);
            String size = textSize.getText();
            int credit = getIntegerValue(textCredit);
            Mobile mobile = new Mobile(model, price, weight, size, credit);
            gadgets.add(mobile);
            String message = "Model: " + model + "\n" +
                    "Price: £" + price + "\n" +
                    "Weight: " + weight + " grams\n" +
                    "Size: " + size + " inches\n" + "Calling Credit: " + credit + " minutes";
            JOptionPane.showMessageDialog(null, message, "Add Mobile Details", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            // Display error message for invalid input
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer.");
        }
    }
    // Method to add an MP3 gadget
    private void addMP3() {
        try {
            String model = textModel.getText();
            double price = getDoubleValue(textPrice);
            int weight = getIntegerValue(textWeight);
            String size = textSize.getText();
            int memory = getIntegerValue(textMemory);
            MP3 mp3 = new MP3(model, price, weight, size, memory);
            gadgets.add(mp3);
            String message = "Model: " + model + "\n" +
                    "Price: £" + price + "\n" +
                    "Weight: " + weight + " grams\n" +
                    "Size: " + size + " inches\n" +
                    "Available Memory: " + memory + " MB";
            JOptionPane.showMessageDialog(null, message, "Add MP3 Details", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException e) {
            // Display error message for invalid input
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer.");
        }
    }

    // Method to clear text fields
    private void clearTextFields() {
        textModel.setText("");
        textPrice.setText("");
        textWeight.setText("");
        textSize.setText("");
        textCredit.setText("");
        textMemory.setText("");
        textPhoneNo.setText("");
        textDuration.setText("");
        textDownload.setText("");
        textDisplayNumber.setText("");
    }
    // Method to display all gadgets
    public void displayAllGadgets() {
        // Method to display all gadgets
            StringBuilder allGadgetsDetails = new StringBuilder();
            for (int i = 0; i < gadgets.size(); i++) {
                allGadgetsDetails.append("Display Number: ").append(i).append("\n");
                allGadgetsDetails.append(gadgets.get(i).toString()).append("\n");
            }
            JOptionPane.showMessageDialog(null, allGadgetsDetails.toString(), "All Gadgets Details", JOptionPane.INFORMATION_MESSAGE);
        }

    // Method to get the download size via GUI input
    private int getDownloadSize() {
        return Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the download size (in MB):"));
    }

    // Method to handle downloading music
    private void downloadMusic() {
        try {
            int displayNumber = getDisplayNumber();
            if (displayNumber >= 0 && displayNumber < gadgets.size()) {
                Gadget selectedGadget = gadgets.get(displayNumber);
                if (selectedGadget instanceof MP3) {
                    int downloadSize = getDownloadSize();
                    ((MP3) selectedGadget).downloadMusic(downloadSize);
                    JOptionPane.showMessageDialog(null, "Music downloaded successfully!", "Download Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Selected gadget is not an MP3 player.", "Invalid Gadget", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid display number. Please select a valid gadget.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }


    private double getDoubleValue(JTextField textField) {
        // Get double value from text field
        try {
            return Double.parseDouble(textField.getText().trim());
        } catch (NumberFormatException e) {
            // Display error message for invalid input
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
            return 0;
        }
    }

    private int getIntegerValue(JTextField textField) {
        // Get integer value from text field
        try {
            return Integer.parseInt(textField.getText().trim());
        } catch (NumberFormatException e) {
            // Display error message for invalid input
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid integer.");
            return 0;
        }
    }

    // Method to get the display number via GUI input
    private int getDisplayNumber() {
        return Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the display number:"));
    }

    // Method to get the phone number via GUI input
    private String getPhoneNumber() {
        return JOptionPane.showInputDialog(null, "Enter the phone number:");
    }

    // Method to get the call duration via GUI input
    private int getDuration() {
        return Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the call duration (in minutes):"));
    }

    // Method to handle making a call
    public void makeCall() {
        try {
            int displayNumber = getDisplayNumber();
            if (displayNumber >= 0 && displayNumber < gadgets.size()) {
                Gadget selectedGadget = gadgets.get(displayNumber);
                if (selectedGadget instanceof Mobile) {
                    String phoneNumber = getPhoneNumber();
                    int duration = getDuration();
                    ((Mobile) selectedGadget).makeCall(phoneNumber, duration);
                    JOptionPane.showMessageDialog(null, "Call made successfully!", "Call Success", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Selected gadget is not a mobile phone.", "Invalid Gadget", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid display number. Please select a valid gadget.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        } catch (IndexOutOfBoundsException e) {
            JOptionPane.showMessageDialog(null, "Invalid display number. Please select a valid gadget.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        }
    }
}