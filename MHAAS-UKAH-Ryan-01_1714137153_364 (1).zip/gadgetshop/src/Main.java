// Main Class
public class Main {
    public static void main(String[] args) {                    // Main Method
        GadgetShop gadgetShop = new GadgetShop();
    }
}
