import java.io.Serializable;

// Define the MP3 class which extends Gadget and implements Serializable interface
class MP3 extends Gadget implements Serializable {

    // Private attributes
    private String model;
    private int availableMemory;

    // Constructor
    public MP3(String model, double price, int weight, String size, int availableMemory) {
        super(model, price, weight, size);
        this.model = model;
        this.availableMemory = availableMemory;
    }
    // Getter method to retrieve the available memory of the MP3 player
    public int getAvailableMemory() {
        return availableMemory;
    }

    // download music method of MP3 class
    public void downloadMusic(int downloadSize) {
        System.out.println("Downloading " + downloadSize + " MB of music...");
        // Code to download music goes here
    }

    // Override toString method
    @Override
    public String toString() {
        return "Model: " + model + "\n" +
         "Available Memory: " + availableMemory + " MB\n\n";
    }
}
