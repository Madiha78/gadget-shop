import javax.swing.*;

// Mobile class extending Gadget attributes
class Mobile extends Gadget {
    private String model;
    private int callingCredit;

    // Constructor
    public Mobile(String model, double price, int weight, String size, int callingCredit) {
        super(model, price, weight, size);
        this.model = model;
        this.callingCredit = callingCredit;
    }

    // Method to make a call
    public void makeCall(String phoneNumber, int duration) {
            System.out.println("Making a call to " + phoneNumber + " for " + duration + " minutes...");

        if (callingCredit >= duration) {
            JOptionPane.showMessageDialog(null, "Calling " + phoneNumber + " for " + duration + " minutes.");
            callingCredit -= duration;
        } else {
            JOptionPane.showMessageDialog(null, "Insufficient credit to make the call.");
        }
    }
    // Override toString method
    @Override
    public String toString() {
        return super.toString() +
                "Model: " + model + "\n";
    }
}
